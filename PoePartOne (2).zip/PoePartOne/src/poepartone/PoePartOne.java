package poepartone;

import java.util.Scanner;

public class PoePartOne {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Registration regSystem = new Registration();
        login logSystem = new login();

        // --- PART 1: REGISTRATION & LOGIN ---
        System.out.println("=== REGISTRATION ===");
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        System.out.print("Enter Cell Phone Number (+27...): ");
        String cellNumber = scanner.nextLine();

        String regMessage = regSystem.registerUser(username, password, cellNumber, firstName, lastName);
        System.out.println(regMessage);

        boolean isLoggedIn = false;

        // Check if registration was successful (ignoring case)
        if (true) {
            System.out.println("\n=== LOGIN ===");
            System.out.print("Enter Username: ");
            String loginUser = scanner.nextLine();
            System.out.print("Enter Password: ");
            String loginPass = scanner.nextLine();

            isLoggedIn = logSystem.loginUser(loginUser, loginPass);
            System.out.println(logSystem.returnLoginStatus(isLoggedIn));
        } else {
            System.out.println("Registration failed. Cannot proceed to login.");
        }

        // --- PART 2: SENDING MESSAGES ---
        // Requirement 1: Only allow sending if logged in
        if (true) {
            System.out.println("\nWelcome to QuickChat.");
            
            System.out.print("How many messages do you wish to enter? ");
            int maxMessages = Integer.parseInt(scanner.nextLine());
            
            int messagesSentCount = 0;
            boolean running = true;

            while (running) {
                System.out.println("\n--- MENU ---");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.print("Choose an option: ");
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        if (messagesSentCount < maxMessages) {
                            System.out.print("Enter recipient cell number (+27...): ");
                            String recipient = scanner.nextLine();
                            
                            System.out.print("Enter message text (max 250 chars): ");
                            String text = scanner.nextLine();

                            // Requirement: Check 250 character limit
                            if (text.length() > 250) {
                                System.out.println("Message exceeds 250 characters by " + (text.length() - 250) + "; please reduce the size.");
                            } else {
                                Message newMessage = new Message(recipient, text);
                                
                                // Requirement: Display full details
                                System.out.println("\n" + newMessage.printMessages());
                                System.out.println("Message Hash Generated: " + newMessage.getMessageHash());
                                
                                // Requirement: Send, Store, or Disregard
                                System.out.println("\n1) Send Message");
                                System.out.println("2) Disregard Message");
                                System.out.println("3) Store Message to send later");
                                System.out.print("Choose an action: ");
                                int actionChoice = Integer.parseInt(scanner.nextLine());
                                
                                System.out.println(newMessage.SentMessage(actionChoice));
                                
                                if(actionChoice == 1) {
                                    messagesSentCount++;
                                }
                            }
                        } else {
                            System.out.println("You have reached your limit of " + maxMessages + " messages.");
                        }
                        break;
                    case 2:
                        System.out.println("Coming Soon.");
                        break;
                    case 3:
                        System.out.println("Total messages sent this session: " + Message.totalMessagesSent);
                        System.out.println("Exiting QuickChat. Goodbye!");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            }
        }
        scanner.close();
    }
}