package poepartone;

import java.util.Random;

public class Message {
    private String messageID;
    private int numMessagesSent;
    private String recipientCell;
    private String messagePayload;
    private String messageHash;
    
    // Tracks messages for the session
    public static int totalMessagesSent = 0;

    public Message(String recipientCell, String messagePayload) {
        this.recipientCell = recipientCell;
        this.messagePayload = messagePayload;
        this.messageID = generateMessageID();
        this.numMessagesSent = totalMessagesSent + 1;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return this.messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (this.recipientCell.startsWith("+") && this.recipientCell.length() <= 12) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash() {
        String idPart = this.messageID.substring(0, 2);
        String[] words = this.messagePayload.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "").toUpperCase();
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "").toUpperCase();
        return idPart + ":" + this.numMessagesSent + ":" + firstWord + lastWord;
    }

    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid choice.";
        }
    }

    public String printMessages() {
        return "Message ID: " + this.messageID + "\n" +
               "Message Hash: " + this.messageHash + "\n" +
               "Recipient: " + this.recipientCell + "\n" +
               "Message: " + this.messagePayload;
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    private void storeMessage() {
        System.out.println("{\n  \"id\": \"" + this.messageID + "\",\n  \"recipient\": \"" + this.recipientCell + "\",\n  \"message\": \"" + this.messagePayload + "\"\n}");
    }
    
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getMessagePayload() { return messagePayload; }
}