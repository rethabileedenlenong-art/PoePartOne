package poepartone; 

    
   import java.util.Scanner;

public class MessageManager {
    
    public String[] sentMessages = new String[5];
    public String[] disregardedMessages = new String[5];
    public String[] storedMessages = new String[5];
    public String[] messageHashes = new String[5];
    public String[] messageIDs = new String[5];
    
    public Message[] allMessages = new Message[5];

    public void loadTestData() {
        allMessages[0] = new Message(1, "27834557896", "Did you get the cake?", "Sent");
        allMessages[1] = new Message(2, "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored");
        allMessages[2] = new Message(3, "+27834484567", "Yohoooo, I am at your gate.", "Disregarded");
        allMessages[3] = new Message(4, "0838884567", "It is dinner time !", "Sent");
        allMessages[4] = new Message(5, "+27838884567", "Ok, I am leaving without you.", "Stored");

        for (int i = 0; i < allMessages.length; i++) {
            Message msg = allMessages[i];
            messageIDs[i] = msg.getMessageID();
            messageHashes[i] = msg.getMessageHash();
            
            if (msg.getFlag().equals("Sent")) {
                sentMessages[i] = msg.getMessageText();
            } else if (msg.getFlag().equals("Stored")) {
                storedMessages[i] = msg.getMessageText();
            } else if (msg.getFlag().equals("Disregarded")) {
                disregardedMessages[i] = msg.getMessageText();
            }
        }
    }

    public void displayStoredMessagesMenu() {
        Scanner scanner = new Scanner(System.in); 
        boolean inMenu = true;
        
        while (inMenu) {
            System.out.println("\n--- STORED MESSAGES MENU ---");
            System.out.println("1. Display sender and recipient of all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search for a message ID");
            System.out.println("4. Search for all messages for a particular recipient");
            System.out.println("5. Delete a message using a message hash");
            System.out.println("6. Display full report");
            System.out.println("0. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1" -> { displaySenderAndRecipient(); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "2" -> { displayLongestMessage(); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "3" -> { searchByID(scanner); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "4" -> { searchByRecipient(scanner); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "5" -> { deleteByHash(scanner); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "6" -> { displayFullReport(); System.out.println("\nPress Enter to continue..."); scanner.nextLine(); }
                case "0" -> inMenu = false;
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    public void displaySenderAndRecipient() {
        System.out.println("\n--- SENDER & RECIPIENT ---");
        for (Message msg : allMessages) {
            if (msg != null && msg.getFlag().equals("Stored")) {
                System.out.println("Sender: Me | Recipient: " + msg.getRecipient());
            }
        }
    }

    public void displayLongestMessage() {
        System.out.println("\n--- LONGEST STORED MESSAGE ---");
        String longestMessage = "";
        
        for (Message msg : allMessages) {
            if (msg != null && msg.getFlag().equals("Stored")) {
                if (msg.getMessageText().length() > longestMessage.length()) {
                    longestMessage = msg.getMessageText();
                }
            }
        }
        
        if (!longestMessage.isEmpty()) {
            System.out.println(longestMessage);
        } else {
            System.out.println("No stored messages found.");
        }
    }

    public void searchByID(Scanner scanner) {
        System.out.println("\n--- SEARCH BY MESSAGE ID ---");
        
        System.out.println("Available Message IDs:");
        for (Message msg : allMessages) {
            if (msg != null) {
                System.out.println("ID: " + msg.getMessageID() + " | Message: " + msg.getMessageText());
            }
        }
        
        System.out.print("\nEnter the Message ID to search for: ");
        String searchId = scanner.nextLine().trim();
        
        boolean found = false;
        for (Message msg : allMessages) {
            if (msg != null && msg.getMessageID().equals(searchId)) {
                System.out.println("\nMessage Found!");
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Message: " + msg.getMessageText());
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("Message ID not found.");
        }
    }

    public void searchByRecipient(Scanner scanner) {
        System.out.println("\n--- SEARCH BY RECIPIENT ---");
        System.out.print("Enter the recipient's phone number to search: ");
        String searchRecipient = scanner.nextLine().trim();
        
        boolean found = false;
        for (Message msg : allMessages) {
            if (msg != null && msg.getRecipient().equals(searchRecipient)) {
                System.out.println("Message: \"" + msg.getMessageText() + "\"");
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No messages found for that recipient.");
        }
    }

    public void deleteByHash(Scanner scanner) {
        System.out.println("\n--- DELETE BY MESSAGE HASH ---");
        
        System.out.println("Available Message Hashes:");
        for (Message msg : allMessages) {
            if (msg != null) {
                System.out.println("Hash: " + msg.getMessageHash() + " | Message: " + msg.getMessageText());
            }
        }
        
        System.out.print("\nEnter the Message Hash to delete: ");
        String searchHash = scanner.nextLine().trim();
        
        boolean found = false;
        for (int i = 0; i < allMessages.length; i++) {
            if (allMessages[i] != null && allMessages[i].getMessageHash().equals(searchHash)) {
                System.out.println("Message: \"" + allMessages[i].getMessageText() + "\" successfully deleted.");
                allMessages[i] = null; 
                found = true;
                break;
            }
        }
        
        if (!found) {
            System.out.println("Message hash not found.");
        }
    }

    public void displayFullReport() {
        System.out.println("\n--- FULL MESSAGE REPORT ---");
        boolean hasMessages = false;
        
        for (Message msg : allMessages) {
            if (msg != null) {
                System.out.println("Message Hash: " + msg.getMessageHash());
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Message: " + msg.getMessageText());
                System.out.println("-------------------------");
                hasMessages = true;
            }
        }
        
        if  (!hasMessages) {
            System.out.println("No messages available to report (they may have been deleted).");
        }
    }

    public void loadFromJSON() {
        System.out.println("Reading JSON file...");
        
        String projectPath = System.getProperty("user.dir");
        java.io.File file = new java.io.File(projectPath + "/messages.json");
        
        if (!file.exists()) {
            try {
                java.io.FileWriter writer =  new java.io.FileWriter(file);
                writer.write("[\n" +
                    "  {\n" +
                    "    \"messageNumber\": 1,\n" +
                    "    \"recipient\": \"27834557896\",\n" +
                    "    \"messageText\": \"Did you get the cake?\",\n" +
                    "    \"flag\": \"Sent\"\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"messageNumber\": 2,\n" +
                    "    \"recipient\": \"+27838884567\",\n" +
                    "    \"messageText\": \"Where are you? You are late! I have asked you to be on time.\",\n" +
                    "    \"flag\": \"Stored\"\n" +
                    "  }\n" +
                    "]");
                writer.close();
                System.out.println("JSON file was missing, so we created it automatically!");
            } catch (Exception e) {
                System.out.println("Could not create JSON file.");
            }
        }

        try {
            java.util.Scanner fileScanner = new java.util.Scanner(file);
            int index = 0;
            String currentRecipient = "";
            String currentMessage = "";
            String currentFlag = "";
            
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine().trim();
                
                if (line .contains("\"recipient\":")) {
                    currentRecipient = line.split(":")[1].replace("\"", "").replace(",", "").trim();
                } else if (line.contains("\"messageText\":")) {
                    currentMessage = line.split(":")[1].replace("\"", "").replace(",", "").trim();
                } else if (line.contains("\"flag\":")) {
                    currentFlag = line.split(":")[1].replace("\"", "").replace(",", "").trim();
                    
                    allMessages[index] = new Message(index + 1, currentRecipient, currentMessage, currentFlag);
                    messageIDs[index] = allMessages[index].getMessageID();
                    messageHashes[index] = allMessages[index].getMessageHash();
                    
                    if (currentFlag.equals("Sent")) {
                        sentMessages[index] = currentMessage;
                    } else if (currentFlag.equals("Stored")) {
                        storedMessages[index] = currentMessage;
                    } else if (currentFlag.equals("Disregarded")) {
                        disregardedMessages[index] = currentMessage;
                    }
                    index++;
                }
            }
            fileScanner.close();
            System.out.println("JSON file loaded successfully!");
            
        } catch (Exception e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
        }
    }
}