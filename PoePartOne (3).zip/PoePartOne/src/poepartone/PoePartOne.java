package poepartone;
import java.util.Scanner;

public class PoePartOne {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MessageManager manager = new MessageManager();
        
        // Load the test data into our arrays
        manager.loadTestData();
        manager.loadFromJSON();

        boolean running = true;
        
        while (running) {
            System.out.println("\n=== QUICKCHAT MAIN MENU ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose an option: ");
            
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System. out.println("Feature coming soon.");
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    running = false;
                    break;
                case "4":
                    // Notice: no scanner passed here anymore
                    manager.displayStoredMessagesMenu();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }
}