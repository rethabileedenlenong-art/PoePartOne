package poepartone;

public class MessageManagerTest {

   
    public static void main(String[] args) {
        System.out.println("=== RUNNING MANUAL TESTS ===");

        testDisplayLongestMessage();
        testDeleteMessage();
        testSearchByRecipient();
        
        System. out.println("\nALL TESTS COMPLETED SUCCESSFULLY!");
    }

    public static void testDisplayLongestMessage() {
        MessageManager manager = new MessageManager();
        manager.loadTestData();
        
        String expected = "Where are you? You are late! I have asked you to be on time.";
        String actual = "";
        
        for (Message msg : manager.allMessages) {
            if (msg != null && msg.getFlag().equals("Stored")) {
                if (msg.getMessageText().length() > actual.length()) {
                    actual = msg.getMessageText();
                }
            }
        }
        
        if (expected.equals(actual)) {
            System.out.println("Test 1 (Longest Message): PASSED");
        } else {
            System.out.println("Test 1 (Longest Message): FAILED");
        }
    }

    public static void testDeleteMessage() {
        MessageManager manager = new MessageManager();
        manager.loadTestData();
        
        String hashToDelete = manager.allMessages[1].getMessageHash();
        
        for (int i = 0; i < manager.allMessages.length; i++) {
            if (manager.allMessages[i] != null && manager.allMessages[i].getMessageHash().equals(hashToDelete)) {
                manager.allMessages[i] = null;
                break;
            }
        }
        
        if (manager.allMessages[1] == null) {
            System.out.println("Test 2 (Delete Message): PASSED");
        } else {
            System. out.println("Test 2 (Delete Message): FAILED");
        }
    }
    
    public static void testSearchByRecipient() {
        MessageManager manager = new MessageManager();
        manager.loadTestData();
        
        String targetRecipient = "+27838884567";
        int count = 0;
        
        for (Message msg : manager.allMessages) {
            if (msg != null && msg.getRecipient().equals(targetRecipient)) {
                count++;
            }
        }
        
        if (count == 2) {
            System.out.println("Test 3 (Search by Recipient): PASSED");
        } else {
            System.out.println("Test 3 (Search by Recipient): FAILED");
        }
    }
}