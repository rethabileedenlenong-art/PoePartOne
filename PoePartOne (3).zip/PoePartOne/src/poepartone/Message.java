package poepartone; 

public class Message {
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String flag;
    private final String messageHash;

    // Constructor
    public Message(int messageNumber, String recipient, String messageText, String flag) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.flag = flag;
        
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    // Generates a 10-digit random ID
    private String generateMessageID() {
        long id = (long) (Math.random() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // Creates the hash (e.g., 27:Di:1)
    public String createMessageHash() {
        String firstTwoRecipient = recipient.substring(0, 2);
        String firstTwoMessage = messageText.substring(0, 2).toUpperCase();
        return firstTwoRecipient + ":" + firstTwoMessage + ":" + messageNumber;
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getFlag() { return flag; }
    public String getMessageHash() { return messageHash; }
}